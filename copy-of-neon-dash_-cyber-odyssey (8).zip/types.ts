
export enum GameMode {
  CUBE = 'CUBE',
  SHIP = 'SHIP'
}

export enum GameStatus {
  MENU = 'MENU',
  PLAYING = 'PLAYING',
  GAMEOVER = 'GAMEOVER'
}

export interface Vector2D {
  x: number;
  y: number;
}

export interface Player {
  y: number;
  vy: number;
  rotation: number;
  mode: GameMode;
  size: number;
  isGrounded: boolean;
}

export enum ObstacleType {
  SPIKE = 'SPIKE',
  BLOCK = 'BLOCK',
  PORTAL = 'PORTAL',
  ORB = 'ORB',
  SAW = 'SAW'
}

export interface Obstacle {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  type: ObstacleType;
  targetMode?: GameMode;
}

export interface GameState {
  status: GameStatus;
  score: number;
  highScore: number;
  distance: number;
}
