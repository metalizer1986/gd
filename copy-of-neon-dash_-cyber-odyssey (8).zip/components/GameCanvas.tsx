
import React, { useRef, useEffect } from 'react';
import { 
  GameMode, 
  Player, 
  Obstacle, 
  ObstacleType 
} from '../types';
import { 
  CANVAS_WIDTH, 
  CANVAS_HEIGHT, 
  GRAVITY, 
  JUMP_FORCE, 
  SHIP_THRUST, 
  SHIP_GRAVITY, 
  BASE_SPEED, 
  PLAYER_X_OFFSET, 
  PLAYER_SIZE, 
  COLORS 
} from '../constants';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
}

interface GameCanvasProps {
  onGameOver: (score: number) => void;
}

const GameCanvas: React.FC<GameCanvasProps> = ({ onGameOver }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number | null>(null);
  
  const playerRef = useRef<Player>({
    y: CANVAS_HEIGHT - 100 - PLAYER_SIZE,
    vy: 0,
    rotation: 0,
    mode: GameMode.CUBE,
    size: PLAYER_SIZE,
    isGrounded: true
  });

  const obstaclesRef = useRef<Obstacle[]>([]);
  const trailRef = useRef<{y: number, rotation: number, opacity: number}[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const frameCountRef = useRef(0);
  const scoreRef = useRef(0);
  const isInputActiveRef = useRef(false);
  const gameSpeedRef = useRef(BASE_SPEED);
  const shakeRef = useRef(0);

  const createParticles = (x: number, y: number, color: string, count = 8) => {
    for (let i = 0; i < count; i++) {
      particlesRef.current.push({
        x, y,
        vx: (Math.random() - 0.5) * 6,
        vy: (Math.random() - 0.5) * 6,
        life: 1.0,
        color
      });
    }
  };

  const spawnObstacle = () => {
    const groundY = CANVAS_HEIGHT - 100;
    const spawnX = CANVAS_WIDTH + 200;
    const rand = Math.random();
    let newObstacle: Obstacle;

    if (rand < 0.35) {
      newObstacle = { id: Math.random().toString(), x: spawnX, y: groundY - 32, width: 32, height: 32, type: ObstacleType.SPIKE };
    } else if (rand < 0.5) {
      newObstacle = { id: Math.random().toString(), x: spawnX, y: groundY - 140 - Math.random() * 80, width: 40, height: 25, type: ObstacleType.ORB };
    } else if (rand < 0.6) {
      newObstacle = { id: Math.random().toString(), x: spawnX, y: groundY - 200, width: 45, height: 140, type: ObstacleType.PORTAL, targetMode: playerRef.current.mode === GameMode.CUBE ? GameMode.SHIP : GameMode.CUBE };
    } else {
      newObstacle = { id: Math.random().toString(), x: spawnX, y: groundY - 40, width: 40, height: 40, type: ObstacleType.BLOCK };
    }
    obstaclesRef.current.push(newObstacle);
  };

  const update = () => {
    const player = playerRef.current;
    const groundY = CANVAS_HEIGHT - 100;

    if (player.mode === GameMode.CUBE) {
      if (isInputActiveRef.current && player.isGrounded) {
        player.vy = JUMP_FORCE;
        player.isGrounded = false;
        shakeRef.current = 3;
        createParticles(PLAYER_X_OFFSET + 16, player.y + 32, COLORS.PRIMARY);
      }
      player.vy += GRAVITY;
      player.y += player.vy;
      if (player.y + player.size >= groundY) {
        if (!player.isGrounded) {
          createParticles(PLAYER_X_OFFSET + 16, groundY, COLORS.PRIMARY, 4);
          shakeRef.current = 1.5;
        }
        player.y = groundY - player.size;
        player.vy = 0;
        player.isGrounded = true;
        player.rotation = Math.round(player.rotation / (Math.PI / 2)) * (Math.PI / 2);
      } else {
        player.rotation += 0.18;
      }
    } else {
      if (isInputActiveRef.current) {
        player.vy += SHIP_THRUST;
        if (frameCountRef.current % 4 === 0) createParticles(PLAYER_X_OFFSET, player.y + 16, COLORS.SECONDARY, 2);
      } else player.vy += SHIP_GRAVITY;
      player.vy *= 0.985;
      player.y += player.vy;
      player.rotation = Math.max(-0.6, Math.min(0.6, player.vy * 0.12));
      if (player.y < 0) { player.y = 0; player.vy = 0; }
      if (player.y + player.size >= groundY) { player.y = groundY - player.size; player.vy = 0; }
    }

    // Shake decay
    if (shakeRef.current > 0) shakeRef.current *= 0.9;

    // Trail & Particles
    if (frameCountRef.current % 2 === 0) {
      trailRef.current.unshift({ y: player.y, rotation: player.rotation, opacity: 0.5 });
      if (trailRef.current.length > 15) trailRef.current.pop();
    }
    trailRef.current.forEach(t => t.opacity -= 0.02);

    particlesRef.current.forEach(p => {
      p.x -= gameSpeedRef.current * 0.4;
      p.y += p.vy;
      p.life -= 0.02;
    });
    particlesRef.current = particlesRef.current.filter(p => p.life > 0);

    // Obstacles
    obstaclesRef.current.forEach(obs => {
      obs.x -= gameSpeedRef.current;
      if (obs.type === ObstacleType.ORB) obs.y += Math.sin(frameCountRef.current * 0.12) * 2;
    });
    obstaclesRef.current = obstaclesRef.current.filter(obs => obs.x + obs.width > -100);

    for (const obs of obstaclesRef.current) {
      const hit = PLAYER_X_OFFSET + 5 < obs.x + obs.width &&
                  PLAYER_X_OFFSET + player.size - 5 > obs.x &&
                  player.y + 5 < obs.y + obs.height &&
                  player.y + player.size - 5 > obs.y;
      if (hit) {
        if (obs.type === ObstacleType.PORTAL) {
          player.mode = obs.targetMode || GameMode.CUBE;
          obstaclesRef.current = obstaclesRef.current.filter(o => o.id !== obs.id);
          createParticles(PLAYER_X_OFFSET + 16, player.y + 16, '#10b981', 12);
          shakeRef.current = 6;
        } else {
          onGameOver(Math.floor(scoreRef.current));
          return false;
        }
      }
    }

    frameCountRef.current++;
    if (frameCountRef.current % 75 === 0) spawnObstacle();
    scoreRef.current += 0.2;
    gameSpeedRef.current += 0.00045;
    return true;
  };

  const draw = (ctx: CanvasRenderingContext2D) => {
    const shakeX = (Math.random() - 0.5) * shakeRef.current;
    const shakeY = (Math.random() - 0.5) * shakeRef.current;
    
    ctx.save();
    ctx.translate(shakeX, shakeY);
    ctx.clearRect(-20, -20, CANVAS_WIDTH + 40, CANVAS_HEIGHT + 40);
    
    const groundY = CANVAS_HEIGHT - 100;

    // Background Sky Gradient
    const grad = ctx.createLinearGradient(0, 0, 0, groundY);
    grad.addColorStop(0, '#020617');
    grad.addColorStop(1, '#0f172a');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Dynamic Cyber Grid
    ctx.strokeStyle = 'rgba(0, 242, 255, 0.08)';
    ctx.lineWidth = 1;
    const gridOffset = (frameCountRef.current * gameSpeedRef.current) % 60;
    const tilt = playerRef.current.vy * 0.5;
    
    ctx.save();
    ctx.globalAlpha = 0.5;
    for (let x = -gridOffset; x < CANVAS_WIDTH + 60; x += 60) {
      ctx.beginPath(); 
      ctx.moveTo(x + tilt, 0); 
      ctx.lineTo(x - tilt, groundY); 
      ctx.stroke();
    }
    for (let y = 0; y < groundY; y += 40) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(CANVAS_WIDTH, y); ctx.stroke();
    }
    ctx.restore();

    // Speed Lines (Visual Wow)
    if (gameSpeedRef.current > BASE_SPEED * 1.2) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
      ctx.lineWidth = 1;
      for (let i = 0; i < 5; i++) {
        const y = (Math.sin(i * 1234.5) * 0.5 + 0.5) * groundY;
        const xStart = CANVAS_WIDTH - ((frameCountRef.current * 15 + i * 200) % (CANVAS_WIDTH + 400));
        ctx.beginPath(); ctx.moveTo(xStart, y); ctx.lineTo(xStart + 100, y); ctx.stroke();
      }
    }

    // Parallax Buildings
    ctx.fillStyle = '#050a1f';
    for(let i=0; i<6; i++) {
        const x = (i * 200 - (frameCountRef.current * 0.4) % 1200);
        ctx.fillRect(x, groundY - 140, 60, 140);
        ctx.fillStyle = 'rgba(0, 242, 255, 0.15)';
        if (frameCountRef.current % 60 < 30) ctx.fillRect(x + 15, groundY - 120, 8, 8);
    }

    // Ground
    ctx.fillStyle = COLORS.GROUND;
    ctx.fillRect(0, groundY, CANVAS_WIDTH, 100);
    ctx.strokeStyle = COLORS.PRIMARY;
    ctx.lineWidth = 4;
    ctx.shadowBlur = 15; ctx.shadowColor = COLORS.PRIMARY;
    ctx.strokeRect(-10, groundY, CANVAS_WIDTH + 20, 2);
    ctx.shadowBlur = 0;

    // Particles
    particlesRef.current.forEach(p => {
      ctx.globalAlpha = p.life;
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x, p.y, 3, 3);
    });
    ctx.globalAlpha = 1;

    // Trail
    const player = playerRef.current;
    const pColor = player.mode === GameMode.SHIP ? COLORS.SECONDARY : COLORS.PRIMARY;
    trailRef.current.forEach((t, i) => {
      ctx.save();
      ctx.globalAlpha = Math.max(0, t.opacity - (i * 0.03));
      ctx.translate(PLAYER_X_OFFSET + player.size/2 - (i * 4), t.y + player.size/2);
      ctx.rotate(t.rotation);
      ctx.fillStyle = pColor;
      ctx.fillRect(-player.size/2, -player.size/2, player.size, player.size);
      ctx.restore();
    });
    ctx.globalAlpha = 1;

    // Obstacles
    obstaclesRef.current.forEach(obs => {
      ctx.save();
      if (obs.type === ObstacleType.ORB) {
        ctx.fillStyle = COLORS.DRONE; ctx.shadowBlur = 25; ctx.shadowColor = COLORS.DRONE;
        ctx.beginPath(); ctx.arc(obs.x + 20, obs.y + 12, 12, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.fillRect(obs.x + 14, obs.y + 6, 4, 4); ctx.fillRect(obs.x + 22, obs.y + 6, 4, 4);
      } else if (obs.type === ObstacleType.SPIKE) {
        ctx.fillStyle = COLORS.SPIKE;
        ctx.beginPath(); ctx.moveTo(obs.x, obs.y+32); ctx.lineTo(obs.x+16, obs.y); ctx.lineTo(obs.x+32, obs.y+32); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.stroke();
      } else if (obs.type === ObstacleType.PORTAL) {
        ctx.strokeStyle = '#10b981'; ctx.lineWidth = 4; ctx.shadowBlur = 20; ctx.shadowColor = '#10b981';
        ctx.strokeRect(obs.x, obs.y, obs.width, obs.height);
        // Energy lines in portal
        ctx.globalAlpha = 0.5 + Math.sin(frameCountRef.current * 0.2) * 0.3;
        ctx.strokeRect(obs.x + 10, obs.y, 2, obs.height);
        ctx.strokeRect(obs.x + obs.width - 10, obs.y, 2, obs.height);
      } else {
        ctx.fillStyle = '#1e293b'; ctx.strokeStyle = COLORS.PRIMARY; ctx.lineWidth = 2;
        ctx.fillRect(obs.x, obs.y, obs.width, obs.height); ctx.strokeRect(obs.x, obs.y, obs.width, obs.height);
      }
      ctx.restore();
    });

    // Player
    ctx.save();
    ctx.translate(PLAYER_X_OFFSET + player.size/2, player.y + player.size/2);
    ctx.rotate(player.rotation);
    ctx.shadowBlur = 30; ctx.shadowColor = pColor; ctx.fillStyle = pColor;
    if (player.mode === GameMode.CUBE) {
      ctx.fillRect(-player.size/2, -player.size/2, player.size, player.size);
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.strokeRect(-player.size/2, -player.size/2, player.size, player.size);
      // Inner detail (cross)
      ctx.fillStyle = 'rgba(255,255,255,0.2)';
      ctx.fillRect(-12, -2, 24, 4); ctx.fillRect(-2, -12, 4, 24);
    } else {
      ctx.beginPath(); ctx.moveTo(-18, 0); ctx.lineTo(18, -18); ctx.lineTo(18, 18); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.fillRect(2, -4, 8, 8);
    }
    ctx.restore();

    // Score UI
    ctx.fillStyle = '#fff'; ctx.font = 'bold 32px Orbitron';
    ctx.shadowBlur = 10; ctx.shadowColor = 'rgba(0,0,0,0.5)';
    ctx.fillText(`${Math.floor(scoreRef.current)}`, 30, 50);
    ctx.restore();
  };

  const gameLoop = () => {
    if (update()) {
      const ctx = canvasRef.current?.getContext('2d');
      if (ctx) draw(ctx);
      requestRef.current = requestAnimationFrame(gameLoop);
    }
  };

  useEffect(() => {
    requestRef.current = requestAnimationFrame(gameLoop);
    const handleInput = (e?: any) => { 
        if(e && e.type === 'keydown' && e.code !== 'Space' && e.code !== 'ArrowUp') return;
        isInputActiveRef.current = true; 
    };
    const endInput = () => { isInputActiveRef.current = false; };
    
    window.addEventListener('mousedown', handleInput);
    window.addEventListener('mouseup', endInput);
    window.addEventListener('touchstart', (e) => { e.preventDefault(); handleInput(); }, { passive: false });
    window.addEventListener('touchend', (e) => { e.preventDefault(); endInput(); }, { passive: false });
    window.addEventListener('keydown', handleInput);
    window.addEventListener('keyup', endInput);

    return () => { 
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      window.removeEventListener('mousedown', handleInput);
      window.removeEventListener('mouseup', endInput);
      window.removeEventListener('keydown', handleInput);
      window.removeEventListener('keyup', endInput);
    };
  }, []);

  return (
    <canvas ref={canvasRef} width={CANVAS_WIDTH} height={CANVAS_HEIGHT} className="w-full h-full object-contain cursor-pointer" />
  );
};

export default GameCanvas;
