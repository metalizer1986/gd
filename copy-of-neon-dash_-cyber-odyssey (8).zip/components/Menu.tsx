
import React from 'react';

interface MenuProps {
  onStart: () => void;
  highScore: number;
}

const Menu: React.FC<MenuProps> = ({ onStart, highScore }) => {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900/90 backdrop-blur-sm">
      <h1 className="text-6xl font-orbitron font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-fuchsia-500 mb-2 drop-shadow-lg">
        NEON DASH
      </h1>
      <p className="text-slate-400 font-medium mb-12 tracking-widest uppercase">Cyber Odyssey</p>
      
      <div className="flex flex-col items-center gap-6">
        <button 
          onClick={onStart}
          className="group relative px-12 py-4 bg-transparent border-2 border-cyan-500 overflow-hidden rounded-full transition-all hover:scale-105 active:scale-95"
        >
          <div className="absolute inset-0 bg-cyan-500 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
          <span className="relative z-10 text-xl font-orbitron font-bold text-cyan-500 group-hover:text-black transition-colors">
            START GAME
          </span>
        </button>

        <div className="text-slate-500 font-orbitron text-sm">
          PERSONAL BEST: <span className="text-fuchsia-400">{highScore}</span>
        </div>
      </div>

      <div className="absolute bottom-10 flex gap-8">
        <div className="flex flex-col items-center">
          <div className="w-8 h-8 bg-cyan-500 border-2 border-white mb-2 shadow-[0_0_10px_#06b6d4]"></div>
          <span className="text-[10px] text-slate-500">CUBE MODE</span>
        </div>
        <div className="flex flex-col items-center">
          <div className="w-8 h-8 bg-fuchsia-500 border-2 border-white rounded-tr-3xl mb-2 shadow-[0_0_10px_#d946ef]"></div>
          <span className="text-[10px] text-slate-500">SHIP MODE</span>
        </div>
      </div>
    </div>
  );
};

export default Menu;
