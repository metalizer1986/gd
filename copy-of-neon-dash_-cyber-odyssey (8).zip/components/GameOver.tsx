
import React from 'react';

interface GameOverProps {
  score: number;
  highScore: number;
  onRestart: () => void;
  onMenu: () => void;
}

const GameOver: React.FC<GameOverProps> = ({ score, highScore, onRestart, onMenu }) => {
  const isNewRecord = score >= highScore && score > 0;

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 backdrop-blur-md animate-in fade-in duration-500">
      <div className="text-center mb-10">
        <h2 className="text-5xl font-orbitron font-bold text-red-500 mb-2">CRASHED!</h2>
        <p className="text-slate-400">Your journey was cut short.</p>
      </div>

      <div className="bg-slate-900 p-8 rounded-2xl border border-slate-700 mb-10 min-w-[300px] flex flex-col items-center">
        <div className="mb-4">
          <p className="text-slate-500 text-xs uppercase tracking-widest mb-1">Final Score</p>
          <p className="text-4xl font-orbitron font-bold text-white">{score}</p>
        </div>
        
        <div>
          <p className="text-slate-500 text-xs uppercase tracking-widest mb-1">High Score</p>
          <p className={`text-xl font-orbitron font-bold ${isNewRecord ? 'text-yellow-400' : 'text-slate-400'}`}>
            {highScore}
            {isNewRecord && <span className="ml-2 text-xs">NEW!</span>}
          </p>
        </div>
      </div>

      <div className="flex gap-4">
        <button 
          onClick={onRestart}
          className="px-8 py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-orbitron font-bold rounded-lg transition-colors shadow-[0_0_15px_rgba(8,145,178,0.4)]"
        >
          RETRY
        </button>
        <button 
          onClick={onMenu}
          className="px-8 py-3 bg-slate-700 hover:bg-slate-600 text-white font-orbitron font-bold rounded-lg transition-colors"
        >
          MENU
        </button>
      </div>
    </div>
  );
};

export default GameOver;
