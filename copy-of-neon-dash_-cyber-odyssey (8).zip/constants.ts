
export const CANVAS_WIDTH = 800;
export const CANVAS_HEIGHT = 450;

export const GRAVITY = 0.8;
export const JUMP_FORCE = -11;
export const SHIP_THRUST = -0.6;
export const SHIP_GRAVITY = 0.35;

export const BASE_SPEED = 6.8;
export const PLAYER_X_OFFSET = 120;
export const PLAYER_SIZE = 32;

export const COLORS = {
  PRIMARY: '#00f2ff', 
  SECONDARY: '#ff00ff', 
  ACCENT: '#ffff00', 
  BACKGROUND: '#020617',
  GROUND: '#111827',
  SPIKE: '#ff4d4d',
  PORTAL: '#10b981',
  DRONE: '#f87171'
};
