
import React, { useState, useEffect, useCallback } from 'react';
import { GameStatus, GameState } from './types';
import GameCanvas from './components/GameCanvas';
import Menu from './components/Menu';
import GameOver from './components/GameOver';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>({
    status: GameStatus.MENU,
    score: 0,
    highScore: parseInt(localStorage.getItem('highScore') || '0'),
    distance: 0
  });

  const startGame = useCallback(() => {
    setGameState(prev => ({ ...prev, status: GameStatus.PLAYING, score: 0, distance: 0 }));
  }, []);

  const handleGameOver = useCallback((finalScore: number) => {
    setGameState(prev => {
      const newHighScore = Math.max(prev.highScore, finalScore);
      localStorage.setItem('highScore', newHighScore.toString());
      return {
        ...prev,
        status: GameStatus.GAMEOVER,
        score: finalScore,
        highScore: newHighScore
      };
    });
  }, []);

  const goToMenu = useCallback(() => {
    setGameState(prev => ({ ...prev, status: GameStatus.MENU }));
  }, []);

  return (
    <div className="relative w-full h-screen bg-slate-950 flex items-center justify-center overflow-hidden">
      {/* Visual background elements */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500 rounded-full blur-[128px]"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-fuchsia-500 rounded-full blur-[128px]"></div>
      </div>

      <div className="relative z-10 w-full max-w-4xl aspect-video bg-black rounded-xl border-4 border-slate-800 shadow-2xl overflow-hidden">
        {gameState.status === GameStatus.MENU && (
          <Menu onStart={startGame} highScore={gameState.highScore} />
        )}
        
        {gameState.status === GameStatus.PLAYING && (
          <GameCanvas onGameOver={handleGameOver} />
        )}

        {gameState.status === GameStatus.GAMEOVER && (
          <GameOver 
            score={gameState.score} 
            highScore={gameState.highScore} 
            onRestart={startGame} 
            onMenu={goToMenu}
          />
        )}
      </div>

      {/* Instructions */}
      <div className="absolute bottom-8 text-slate-400 text-sm font-medium animate-pulse">
        PRESS SPACE OR TAP TO JUMP / FLY
      </div>
    </div>
  );
};

export default App;
